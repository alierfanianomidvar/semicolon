package com.unipd.semicolon.core.entity.enums;

public enum PharmacyStatus {
    ACTIVE,
    INACTIVE
}
