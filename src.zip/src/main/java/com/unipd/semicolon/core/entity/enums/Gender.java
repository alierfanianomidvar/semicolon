package com.unipd.semicolon.core.entity.enums;

public enum Gender {
    MALE,
    FEMALE,
    NON_BINARY
}
