package com.unipd.semicolon.core.repository.entity.Imp;

import com.unipd.semicolon.core.entity.Login;
import com.unipd.semicolon.core.repository.entity.LoginRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Repository;



@Repository
public class LoginRepositoryImp extends CustomRepository {


}
