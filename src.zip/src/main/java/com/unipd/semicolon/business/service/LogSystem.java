package com.unipd.semicolon.business.service;

public interface LogSystem {

    void logUtil(String msg);
}
