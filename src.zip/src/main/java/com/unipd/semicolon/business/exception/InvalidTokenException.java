package com.unipd.semicolon.business.exception;

public class InvalidTokenException extends CustomException {

  public InvalidTokenException() {
    super("Invalid_Token_Exception");
  }
}
